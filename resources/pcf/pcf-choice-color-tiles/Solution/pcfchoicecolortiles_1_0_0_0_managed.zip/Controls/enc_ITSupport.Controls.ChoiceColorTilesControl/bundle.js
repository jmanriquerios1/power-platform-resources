/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ChoiceColorTilesControl/ChoiceColorTilesView.tsx"
/*!**********************************************************!*\
  !*** ./ChoiceColorTilesControl/ChoiceColorTilesView.tsx ***!
  \**********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ChoiceColorTilesView: () => (/* binding */ ChoiceColorTilesView)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\nfunction _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }\nfunction _nonIterableRest() { throw new TypeError(\"Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.\"); }\nfunction _unsupportedIterableToArray(r, a) { if (r) { if (\"string\" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return \"Object\" === t && r.constructor && (t = r.constructor.name), \"Map\" === t || \"Set\" === t ? Array.from(r) : \"Arguments\" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }\nfunction _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }\nfunction _iterableToArrayLimit(r, l) { var t = null == r ? null : \"undefined\" != typeof Symbol && r[Symbol.iterator] || r[\"@@iterator\"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }\nfunction _arrayWithHoles(r) { if (Array.isArray(r)) return r; }\n;\nvar FALLBACK_COLORS = [\"#2563EB\", \"#0F766E\", \"#7C3AED\", \"#DB2777\", \"#CA8A04\", \"#EA580C\", \"#0891B2\", \"#334155\"];\nvar styles = {\n  root: {\n    width: \"100%\",\n    boxSizing: \"border-box\",\n    fontFamily: \"'Segoe UI', sans-serif\",\n    color: \"#201f1e\",\n    display: \"flex\",\n    flexDirection: \"column\",\n    gap: \"8px\"\n  },\n  group: {\n    display: \"grid\",\n    gap: \"8px\"\n  },\n  tile: {\n    borderRadius: \"8px\",\n    border: \"1px solid #d1d1d1\",\n    backgroundColor: \"#ffffff\",\n    padding: \"10px 12px\",\n    minHeight: \"52px\",\n    textAlign: \"left\",\n    cursor: \"pointer\",\n    display: \"flex\",\n    flexDirection: \"column\",\n    justifyContent: \"space-between\",\n    boxSizing: \"border-box\",\n    transition: \"all 120ms ease\",\n    outline: \"none\"\n  },\n  tileCompact: {\n    minHeight: \"42px\",\n    padding: \"8px 10px\"\n  },\n  tileLabel: {\n    fontSize: \"13px\",\n    lineHeight: \"18px\",\n    fontWeight: 600,\n    color: \"#201f1e\"\n  },\n  tileSelected: {\n    borderWidth: \"2px\",\n    boxShadow: \"inset 0 0 0 1px rgba(0,0,0,0.03)\"\n  },\n  tileDisabled: {\n    cursor: \"not-allowed\",\n    opacity: 0.7\n  },\n  tileReadOnlySelected: {\n    opacity: 1\n  },\n  selectedHint: {\n    marginTop: \"6px\",\n    fontSize: \"11px\",\n    color: \"#323130\"\n  },\n  empty: {\n    padding: \"10px\",\n    border: \"1px solid #e1dfdd\",\n    borderRadius: \"8px\",\n    fontSize: \"12px\",\n    color: \"#605e5c\",\n    backgroundColor: \"#faf9f8\"\n  },\n  clearButton: {\n    border: \"1px solid #8a8886\",\n    borderRadius: \"4px\",\n    backgroundColor: \"#ffffff\",\n    color: \"#323130\",\n    padding: \"6px 10px\",\n    fontSize: \"12px\",\n    cursor: \"pointer\",\n    width: \"fit-content\"\n  }\n};\nfunction getBooleanInput(input, defaultValue) {\n  var raw = input === null || input === void 0 ? void 0 : input.raw;\n  if (typeof raw === \"boolean\") return raw;\n  return defaultValue;\n}\nfunction getNumberInput(input, defaultValue) {\n  var raw = input === null || input === void 0 ? void 0 : input.raw;\n  if (typeof raw === \"number\" && Number.isFinite(raw) && raw > 0) return raw;\n  return defaultValue;\n}\nfunction normalizeColor(value) {\n  if (!value) return undefined;\n  var trimmed = value.trim();\n  if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed)) return trimmed;\n  return undefined;\n}\nfunction parseColorMapping(raw) {\n  if (!raw || raw.trim().length === 0) return {};\n  try {\n    var parsed = JSON.parse(raw);\n    if (!parsed || typeof parsed !== \"object\") return {};\n    var mapping = {};\n    for (var _ref3 of Object.entries(parsed)) {\n      var _ref2 = _slicedToArray(_ref3, 2);\n      var key = _ref2[0];\n      var value = _ref2[1];\n      if (typeof key !== \"string\") continue;\n      if (typeof value !== \"string\") continue;\n      var color = normalizeColor(value);\n      if (color) mapping[key.toLowerCase()] = color;\n    }\n    return mapping;\n  } catch (_a) {\n    if (typeof console !== \"undefined\") {\n      console.debug(\"[ChoiceColorTilesControl] Invalid colorMappingJson. Using fallback palette.\");\n    }\n    return {};\n  }\n}\nfunction readOptionColor(option) {\n  var candidates = [\"Color\", \"color\", \"ColorHexValue\", \"colorHexValue\", \"hexColor\"];\n  for (var candidate of candidates) {\n    var raw = option[candidate];\n    if (typeof raw === \"string\") {\n      var color = normalizeColor(raw);\n      if (color) return color;\n    }\n  }\n  return undefined;\n}\nfunction readOptionLabel(option) {\n  var _a, _b;\n  var label = (_a = option.Label) !== null && _a !== void 0 ? _a : option.label;\n  if (typeof label === \"string\" && label.trim().length > 0) return label;\n  if (label && typeof label === \"object\") {\n    var userLocalizedLabel = label.UserLocalizedLabel;\n    if (userLocalizedLabel && typeof userLocalizedLabel.Label === \"string\" && userLocalizedLabel.Label.trim().length > 0) {\n      return userLocalizedLabel.Label;\n    }\n    var localLabel = label.LocalizedLabels;\n    if (Array.isArray(localLabel) && localLabel.length > 0) {\n      var first = (_b = localLabel[0]) === null || _b === void 0 ? void 0 : _b.Label;\n      if (typeof first === \"string\" && first.trim().length > 0) return first;\n    }\n  }\n  return undefined;\n}\nfunction readOptionValue(option) {\n  var _a;\n  var rawValue = (_a = option.Value) !== null && _a !== void 0 ? _a : option.value;\n  if (typeof rawValue === \"number\") return rawValue;\n  if (typeof rawValue === \"string\" && rawValue.trim().length > 0) {\n    var parsed = Number(rawValue);\n    if (Number.isFinite(parsed)) return parsed;\n  }\n  return undefined;\n}\nfunction extractChoiceOptions(choiceProperty) {\n  try {\n    var attributes = choiceProperty.attributes;\n    var sources = [attributes === null || attributes === void 0 ? void 0 : attributes.Options, attributes === null || attributes === void 0 ? void 0 : attributes.options, choiceProperty.options, choiceProperty.Options];\n    for (var source of sources) {\n      if (!Array.isArray(source)) continue;\n      var result = source.map(optionRaw => {\n        if (!optionRaw || typeof optionRaw !== \"object\") return undefined;\n        var option = optionRaw;\n        var value = readOptionValue(option);\n        var label = readOptionLabel(option);\n        if (value === undefined || !label) return undefined;\n        return {\n          value,\n          label,\n          color: readOptionColor(option)\n        };\n      }).filter(item => item !== undefined);\n      if (result.length > 0) return result;\n    }\n  } catch (error) {\n    console.warn(\"[ChoiceColorTilesControl] Failed to parse choice option metadata.\", error);\n  }\n  return [];\n}\nfunction colorToTint(hexColor) {\n  var normalized = hexColor.replace(\"#\", \"\");\n  var full = normalized.length === 3 ? normalized.split(\"\").map(c => c + c).join(\"\") : normalized;\n  var r = parseInt(full.slice(0, 2), 16);\n  var g = parseInt(full.slice(2, 4), 16);\n  var b = parseInt(full.slice(4, 6), 16);\n  return \"rgba(\".concat(r, \", \").concat(g, \", \").concat(b, \", 0.12)\");\n}\nfunction getFallbackColor(optionValue) {\n  var index = Math.abs(optionValue) % FALLBACK_COLORS.length;\n  return FALLBACK_COLORS[index];\n}\nfunction resolveTileColorInfo(option, useChoiceColors, mapping) {\n  var _a;\n  var labelKey = option.label.toLowerCase();\n  var valueKey = String(option.value).toLowerCase();\n  var metadataColor = useChoiceColors ? normalizeColor(option.color) : undefined;\n  var mappingColor = (_a = mapping[labelKey]) !== null && _a !== void 0 ? _a : mapping[valueKey];\n  if (metadataColor) {\n    return {\n      metadataColor,\n      mappingColor,\n      finalColor: metadataColor,\n      finalColorSource: \"metadata\"\n    };\n  }\n  if (mappingColor) {\n    return {\n      metadataColor,\n      mappingColor,\n      finalColor: mappingColor,\n      finalColorSource: \"mapping\"\n    };\n  }\n  return {\n    metadataColor,\n    mappingColor,\n    finalColor: getFallbackColor(option.value),\n    finalColorSource: \"fallback\"\n  };\n}\nfunction getRequiredLevel(choiceProperty) {\n  var _a;\n  var attributes = choiceProperty.attributes;\n  var requiredLevel = (_a = attributes === null || attributes === void 0 ? void 0 : attributes.RequiredLevel) !== null && _a !== void 0 ? _a : attributes === null || attributes === void 0 ? void 0 : attributes.requiredLevel;\n  return typeof requiredLevel === \"string\" ? requiredLevel : \"none\";\n}\nfunction getIsEditable(choiceProperty, isControlDisabled) {\n  var _a;\n  if (isControlDisabled) return false;\n  var security = (_a = choiceProperty.security) !== null && _a !== void 0 ? _a : undefined;\n  if (security && security.editable === false) return false;\n  return true;\n}\nfunction getOptionsSource(choiceProperty) {\n  if (!choiceProperty) return [];\n  var attributes = choiceProperty.attributes;\n  return [attributes === null || attributes === void 0 ? void 0 : attributes.Options, attributes === null || attributes === void 0 ? void 0 : attributes.options, choiceProperty.options, choiceProperty.Options];\n}\nfunction inferDesignerMode(context) {\n  var mode = context.mode;\n  if (!mode) return false;\n  var authoringCandidates = [\"isAuthoringMode\", \"isControlInError\", \"isDesignMode\"];\n  for (var key of authoringCandidates) {\n    if (mode[key] === true) return true;\n  }\n  return false;\n}\nfunction resolveColorSourceSummary(values) {\n  var _a;\n  if (values.length === 0) return \"none\";\n  var sources = new Set(values.map(value => value.finalColorSource));\n  if (sources.size === 1) {\n    var first = values[0];\n    return (_a = first === null || first === void 0 ? void 0 : first.finalColorSource) !== null && _a !== void 0 ? _a : \"none\";\n  }\n  return \"mixed\";\n}\nfunction ChoiceColorTilesView(_ref4) {\n  var context = _ref4.context,\n    selectedValue = _ref4.selectedValue,\n    onSelectionChange = _ref4.onSelectionChange;\n  var _a, _b, _c, _d;\n  var choiceProperty = (_a = context.parameters) === null || _a === void 0 ? void 0 : _a.selectedChoice;\n  var options = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    if (!choiceProperty) return [];\n    return extractChoiceOptions(choiceProperty);\n  }, [choiceProperty]);\n  var columnsPerRow = Math.max(1, Math.min(4, getNumberInput(context.parameters.columnsPerRow, 4)));\n  var useChoiceColors = getBooleanInput(context.parameters.useChoiceColors, true);\n  var showSelectedIcon = getBooleanInput(context.parameters.showSelectedIcon, true);\n  var allowClear = getBooleanInput(context.parameters.allowClear, false);\n  var compactMode = getBooleanInput(context.parameters.compactMode, false);\n  var showOnlySelectedWhenReadOnly = getBooleanInput(context.parameters.showOnlySelectedWhenReadOnly, false);\n  var colorMapping = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => parseColorMapping(context.parameters.colorMappingJson.raw), [context.parameters.colorMappingJson.raw]);\n  var debugEnabledRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(typeof window !== \"undefined\" && window.location.search.includes(\"choiceColorTilesDebug=1\"));\n  var isEditable = choiceProperty ? getIsEditable(choiceProperty, ((_b = context.mode) === null || _b === void 0 ? void 0 : _b.isControlDisabled) === true) : false;\n  var isRequired = choiceProperty ? getRequiredLevel(choiceProperty) !== \"none\" : false;\n  var tileRefs = react__WEBPACK_IMPORTED_MODULE_0__.useRef([]);\n  var optionSources = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => getOptionsSource(choiceProperty), [choiceProperty]);\n  var hasOptionsInMetadata = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => optionSources.some(source => Array.isArray(source)), [optionSources]);\n  var hasAttributes = Boolean(choiceProperty && choiceProperty.attributes);\n  var isDesignerLike = inferDesignerMode(context);\n  var isDesignerFallback = (!choiceProperty || !hasAttributes || !hasOptionsInMetadata) && options.length === 0;\n  var displayedOptions = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    if (isEditable || !showOnlySelectedWhenReadOnly || selectedValue === null) return options;\n    return options.filter(option => option.value === selectedValue);\n  }, [isEditable, options, selectedValue, showOnlySelectedWhenReadOnly]);\n  var resolvedColorsByValue = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    var map = new Map();\n    for (var option of displayedOptions) {\n      map.set(option.value, resolveTileColorInfo(option, useChoiceColors, colorMapping));\n    }\n    return map;\n  }, [colorMapping, displayedOptions, useChoiceColors]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    var _a, _b;\n    var shouldLog = debugEnabledRef.current || isDesignerLike || isDesignerFallback;\n    if (!shouldLog) return;\n    var fallbackWithoutMetadataOrMapping = false;\n    var debugColorValues = [];\n    for (var option of displayedOptions) {\n      var resolved = resolvedColorsByValue.get(option.value);\n      if (!resolved) continue;\n      debugColorValues.push(resolved);\n      console.debug(\"[ChoiceColorTilesControl] option metadata\", {\n        optionLabel: option.label,\n        optionValue: option.value,\n        metadataColor: (_a = resolved.metadataColor) !== null && _a !== void 0 ? _a : null,\n        mappingColor: (_b = resolved.mappingColor) !== null && _b !== void 0 ? _b : null,\n        finalColorSource: resolved.finalColorSource,\n        finalColor: resolved.finalColor\n      });\n      if (resolved.finalColorSource === \"fallback\" && !resolved.metadataColor && !resolved.mappingColor) {\n        fallbackWithoutMetadataOrMapping = true;\n      }\n    }\n    if (fallbackWithoutMetadataOrMapping) {\n      console.warn(\"[ChoiceColorTilesControl] Choice colors were not exposed by metadata; using fallback colors.\");\n    }\n    var availability = {\n      hasSelectedChoiceParameter: Boolean(choiceProperty),\n      hasRawValue: choiceProperty ? choiceProperty.raw !== undefined && choiceProperty.raw !== null : false,\n      hasAttributes,\n      hasOptions: hasOptionsInMetadata,\n      optionCount: displayedOptions.length,\n      isDesignerFallback,\n      colorSource: resolveColorSourceSummary(debugColorValues)\n    };\n    console.debug(\"[ChoiceColorTilesControl] context availability\", availability);\n  }, [choiceProperty, displayedOptions, hasAttributes, hasOptionsInMetadata, isDesignerFallback, isDesignerLike, resolvedColorsByValue]);\n  var handleTileClick = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(value => {\n    if (!isEditable) return;\n    onSelectionChange(value);\n  }, [isEditable, onSelectionChange]);\n  var handleKeyDown = react__WEBPACK_IMPORTED_MODULE_0__.useCallback((event, optionValue, optionIndex) => {\n    var _a;\n    if (event.key === \" \" || event.key === \"Enter\") {\n      event.preventDefault();\n      handleTileClick(optionValue);\n      return;\n    }\n    var total = displayedOptions.length;\n    if (total === 0) return;\n    var nextIndex = optionIndex;\n    if (event.key === \"ArrowRight\") nextIndex = (optionIndex + 1) % total;\n    if (event.key === \"ArrowLeft\") nextIndex = (optionIndex - 1 + total) % total;\n    if (event.key === \"ArrowDown\") nextIndex = Math.min(optionIndex + columnsPerRow, total - 1);\n    if (event.key === \"ArrowUp\") nextIndex = Math.max(optionIndex - columnsPerRow, 0);\n    if (nextIndex !== optionIndex) {\n      event.preventDefault();\n      (_a = tileRefs.current[nextIndex]) === null || _a === void 0 ? void 0 : _a.focus();\n    }\n  }, [columnsPerRow, displayedOptions.length, handleTileClick]);\n  if (isDesignerFallback) {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: styles.empty\n    }, \"Choice preview unavailable in designer.\");\n  }\n  if (options.length === 0) {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: styles.empty\n    }, \"No options available.\");\n  }\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: styles.root\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: Object.assign(Object.assign({}, styles.group), {\n      gridTemplateColumns: \"repeat(\".concat(columnsPerRow, \", minmax(0, 1fr))\")\n    }),\n    role: \"radiogroup\",\n    \"aria-label\": (_d = (_c = choiceProperty === null || choiceProperty === void 0 ? void 0 : choiceProperty.attributes) === null || _c === void 0 ? void 0 : _c.DisplayName) !== null && _d !== void 0 ? _d : \"Choice options\"\n  }, displayedOptions.map((option, index) => {\n    var _a;\n    var isSelected = selectedValue === option.value;\n    var colorInfo = (_a = resolvedColorsByValue.get(option.value)) !== null && _a !== void 0 ? _a : resolveTileColorInfo(option, useChoiceColors, colorMapping);\n    var tileColor = colorInfo.finalColor;\n    var selectedBackground = colorToTint(tileColor);\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n      key: option.value,\n      type: \"button\",\n      ref: element => {\n        tileRefs.current[index] = element;\n      },\n      style: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, styles.tile), compactMode ? styles.tileCompact : {}), {\n        borderColor: isSelected ? tileColor : \"#d1d1d1\",\n        backgroundColor: isSelected ? selectedBackground : \"#ffffff\"\n      }), isSelected ? styles.tileSelected : {}), !isEditable ? styles.tileDisabled : {}), !isEditable && isSelected ? styles.tileReadOnlySelected : {}),\n      role: \"radio\",\n      \"aria-checked\": isSelected,\n      \"aria-label\": option.label,\n      disabled: !isEditable,\n      onClick: () => handleTileClick(option.value),\n      onKeyDown: event => handleKeyDown(event, option.value, index)\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: styles.tileLabel\n    }, option.label), showSelectedIcon && isSelected ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: styles.selectedHint\n    }, \"\\u2713 Selected\") : null);\n  })), allowClear && !isRequired && isEditable && selectedValue !== null ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    type: \"button\",\n    style: styles.clearButton,\n    onClick: () => onSelectionChange(null)\n  }, \"Clear selection\")) : null);\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoiceColorTilesControl/ChoiceColorTilesView.tsx?\n}");

/***/ },

/***/ "./ChoiceColorTilesControl/index.ts"
/*!******************************************!*\
  !*** ./ChoiceColorTilesControl/index.ts ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ChoiceColorTilesControl: () => (/* binding */ ChoiceColorTilesControl)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _ChoiceColorTilesView__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ChoiceColorTilesView */ \"./ChoiceColorTilesControl/ChoiceColorTilesView.tsx\");\n\n\nclass ChoiceColorTilesControl {\n  constructor() {\n    this.notifyOutputChanged = null;\n    this.pendingValue = undefined;\n  }\n  init(context, notifyOutputChanged, _state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(true);\n  }\n  updateView(context) {\n    var _a, _b;\n    var selectedChoiceParameter = (_a = context.parameters) === null || _a === void 0 ? void 0 : _a.selectedChoice;\n    var rawValue = (_b = selectedChoiceParameter === null || selectedChoiceParameter === void 0 ? void 0 : selectedChoiceParameter.raw) !== null && _b !== void 0 ? _b : null;\n    if (this.pendingValue !== undefined && this.pendingValue === rawValue) {\n      this.pendingValue = undefined;\n    }\n    var selectedValue = this.pendingValue !== undefined ? this.pendingValue : rawValue;\n    var props = {\n      context,\n      selectedValue,\n      onSelectionChange: value => {\n        var _a;\n        this.pendingValue = value;\n        (_a = this.notifyOutputChanged) === null || _a === void 0 ? void 0 : _a.call(this);\n      }\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ChoiceColorTilesView__WEBPACK_IMPORTED_MODULE_1__.ChoiceColorTilesView, props);\n  }\n  getOutputs() {\n    var _a;\n    if (this.pendingValue === undefined) {\n      return {};\n    }\n    return {\n      selectedChoice: (_a = this.pendingValue) !== null && _a !== void 0 ? _a : undefined\n    };\n  }\n  destroy() {\n    this.notifyOutputChanged = null;\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoiceColorTilesControl/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./ChoiceColorTilesControl/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ITSupport.Controls.ChoiceColorTilesControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoiceColorTilesControl);
} else {
	var ITSupport = ITSupport || {};
	ITSupport.Controls = ITSupport.Controls || {};
	ITSupport.Controls.ChoiceColorTilesControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoiceColorTilesControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}